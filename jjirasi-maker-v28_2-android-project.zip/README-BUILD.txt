찌라시 메이커 — GitHub + update.sh 빌드용 패키지 (v27.4 / versionCode 2704)

이 ZIP 은 update.sh 가 그대로 먹을 수 있는 모양입니다.
루트에 project/ 폴더 하나만 들어 있습니다.

── 처음 한 번만 ──────────────────────────────────────────────
1. 저장소 루트에 update.sh 를 올립니다.
   (update.sh 는 ZIP 안에 넣지 않고 따로 드립니다. ZIP 을 푸는 시점에
    실행 중인 자기 자신을 덮어쓰면 bash 가 스크립트를 이어 읽다 엉키기 때문입니다)
2. 저장소 루트에 이 ZIP 을 그대로 올립니다. 이름은 아무거나 괜찮습니다.
   update.sh 가 루트의 모든 .zip 을 훑어 versionCode 가 가장 높은 것을 고릅니다.
3. 서명 키스토어는 신경 쓰지 않아도 됩니다.
   - 저장소나 워크스페이스에 release.jks 계열 파일이 있으면 그것을 씁니다.
     (AI Log EPUB 것을 그대로 재사용해도 됩니다. 비밀번호를 자동으로 맞춰 봅니다)
   - 아무것도 없으면 스크립트가 새 키를 만들고, 같은 폴더에
     jjirasi-release.jks.base64.txt 도 함께 남깁니다.
     ★ Codespaces 는 컨테이너가 새로 만들어지면 파일이 사라집니다.
       이 .base64.txt 를 반드시 저장소에 커밋해 두세요. 안 그러면 다음에
       다른 키로 빌드되어 덮어쓰기 업데이트가 막힙니다.
4. 글꼴을 project/app/src/main/assets/assets/fonts/ 에 넣습니다.
   update.sh 는 ZIP 을 덮어쓰기로 풀기 때문에 여기 넣은 글꼴은 다음 빌드에도 남습니다.
5. bash update.sh

── 이후 업데이트 ─────────────────────────────────────────────
새 ZIP 을 저장소 루트에 올리고 bash update.sh 만 실행하면 됩니다.
같은 ZIP 을 두 번 빌드하려 하면 스크립트가 막습니다. 정말 다시 하려면 --force.

── update.sh 에서 이 앱에 맞게 바꾼 곳 ───────────────────────
스크립트 맨 위 상수 6개로 모아 두었습니다. 다른 앱에 재사용할 때 여기만 고치면 됩니다.
  APP_NAME     찌라시 메이커
  APP_SLUG     jjirasi        → 도구 폴더 ~/.jjirasi-tools, 기록 파일 .jjirasi_last_zip
  APK_PREFIX   Jjirasi_Maker  → out/Jjirasi_Maker_v27_4_날짜.apk
  ZIP_HINT     ZIP 을 못 찾았을 때 안내할 이름
  ASSET_PROBE  assets/app.js
  ASSET_MARK   JJIRASI_BUILD

그 밖에 고친 것:
- 키스토어 후보 이름에 jjirasi-release.jks 계열을 먼저 넣고, 기존 release.jks 도 그대로 봅니다.
- 키스토어가 없으면 죽는 대신 새로 만듭니다(PKCS12, 30년). base64 백업본도 같이 남깁니다.
- 비밀번호를 후보 목록으로 차례로 시도합니다: jjirasi-release → ailog-release → android.
  암호.txt 가 있으면 그 값을 맨 앞에 놓습니다.
- 별칭을 키스토어에서 직접 읽어 씁니다. 원본은 keytool 출력에서 "Alias" 라는 낱말을
  찾았는데, 영어 로케일 keytool 은 그 낱말을 출력하지 않아 목록이 늘 비어 있었습니다.
- EXPECTED_SHA256 은 비워서 보냅니다. 첫 빌드 때 화면에 붙여 넣을 한 줄이 나옵니다.
- APK 자산 확인이 "파일이 있는지"에서 "이번 자산의 표식이 실제로 들어갔는지"로 바뀌었습니다.
  app.js 첫 줄의 /* JJIRASI_BUILD v28.0 code=2800 */ 를 APK 안에서 직접 찾습니다.
  옛 자산이 그대로 들어가도 통과하던 구멍을 막은 것입니다.
- versionName 을 따옴표 안의 값 그대로 읽습니다. (전에는 27.4 에서 27 만 읽었습니다)
- Android SDK 가 없으면 스스로 내려받아 설치합니다 (5/7 단계).
  cmdline-tools → 라이선스 동의 → platform-tools, android-34, build-tools 34.0.0.
  ANDROID_HOME 이 이미 쓸 만하면 그대로 씁니다. 처음 한 번만 몇 분 걸립니다.
  compileSdk 를 바꾸면 스크립트 위쪽 COMPILE_SDK / BUILD_TOOLS 도 같이 맞춰 주세요.

── 주의 ──────────────────────────────────────────────────────
이 안의 project/ 는 새로 만든 WebView 껍데기입니다.
찌라시 메이커용 안드로이드 프로젝트를 이미 갖고 계시다면, 이 ZIP 을 그대로 풀면
기존 project/ 를 덮어씁니다. 그 경우에는 assets 4개 파일만 옮기시고
project/ 는 쓰지 마세요.

패키지 이름 com.tabloid.jjirasi, 최소 안드로이드 7.0(API 24).
